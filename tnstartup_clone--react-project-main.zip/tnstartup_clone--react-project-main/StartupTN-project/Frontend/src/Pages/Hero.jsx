export default function Hero() {
  return (
    <div>
      <img
        src="https://startuptn.in/images/Banner/Thiruvizha%20Web%20Banner%20(5).png"
        alt="StartupTN Content"
        width="100%"
      />
    </div>
  );
}
